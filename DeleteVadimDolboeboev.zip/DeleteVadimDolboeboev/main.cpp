#include <Windows.h>
#include "kthook/kthook.hpp"

using TimerUpdate_t = void(__cdecl*)();
using AddMessageJumpQ__Handler = void(__cdecl*)(char*, unsigned int, unsigned short, bool);
kthook::kthook_simple<AddMessageJumpQ__Handler> AddMessageJumpQ__HandlerHook;
void AddMessageJumpQ__HandlerHooked(const decltype(AddMessageJumpQ__HandlerHook)& hook, char* text, unsigned int time, unsigned short flag, bool bPreviousBrief)
{
    if (strstr(text, "Vadim Boev") != NULL)
        return;
    return hook.get_trampoline()(text, time, flag, bPreviousBrief);
}

kthook::kthook_simple<TimerUpdate_t> TimerUpdateHook;
uintptr_t samp = reinterpret_cast<uintptr_t>(GetModuleHandleA("samp.dll"));

void TimerUpdateHooked(const decltype(TimerUpdateHook)& hook)
{
    static bool inited = false;
    void* CInput = *reinterpret_cast<void**>(reinterpret_cast<DWORD>(GetModuleHandle(L"samp.dll")) + 0x26E8CC);
    if (CInput != nullptr && !inited)
    {
        inited = true;
        AddMessageJumpQ__HandlerHook.set_dest(0x69F1E0);
        AddMessageJumpQ__HandlerHook.set_cb([](auto&&... args)
            {
                return AddMessageJumpQ__HandlerHooked(args...);
            }
        );
        AddMessageJumpQ__HandlerHook.install();
    }

    hook.get_trampoline()();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH: {
        DisableThreadLibraryCalls(hModule);
        TimerUpdateHook.set_dest(0x561B10);
        TimerUpdateHook.set_cb(&TimerUpdateHooked);
        TimerUpdateHook.install();
        break;
    }
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}